# CONTENTS OF PROJECT
-------------------









# FUNCTIONS USED
--------------

	1. strlen

	2. strrev

	3. itoa

	4. putchar

	5. print_char

	6. print_string

	7. print_int

	8. print _u_int

	9. print_binary

	10. print_octal

	11. print_hex

	12. print_rev

	13. print _rot13


# PROTOTYPES
----------

	char *itoa(int i, char *strout, int base);
	int _printf(const char *format, ...);
	int _strlen_recursion(char *s);
	int _putchar(char c);
	void strrev(char *s);
	int print_char(va_list list);
	int print_string(va_list list);
	int print_int(va_list list);
	int print_u_int(va_list list);
	int print_binary(va_list list);
	int print_octal(va_list list);
	int print_hex(va_list list);
	int print_rev(va_list list);
	int print_rot13(va_list list);
	int(*funtion (char))(va_list list);


Programers:
-----------

Talisha White
Hector Lozano
